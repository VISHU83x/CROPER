let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");
let img = new Image();

/* ================= IMAGE LOAD ================= */
document.getElementById("upload").addEventListener("change", function (e) {
  let file = e.target.files[0];
  if (!file) return;

  let reader = new FileReader();
  reader.onload = function (event) {
    img.onload = function () {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      document.getElementById("downloadArea").innerHTML = "";
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
});

/* ================= APPLY SIZE / CROP ================= */
function applyPreset() {
  let preset = document.getElementById("preset").value;
  let w = document.getElementById("w").value;
  let h = document.getElementById("h").value;

  if (preset) {
    let s = preset.split("x");
    w = parseInt(s[0]);
    h = parseInt(s[1]);
  }

  w = parseInt(w);
  h = parseInt(h);

  if (!w || !h) {
    alert("Width & Height ya exam preset select karo");
    return;
  }

  let imageData = ctx.getImageData(0, 0, w, h);
  canvas.width = w;
  canvas.height = h;
  ctx.putImageData(imageData, 0, 0);
}

/* ================= DOWNLOAD LINK HELPER ================= */
function showDownloadLink(data, filename) {
  let area = document.getElementById("downloadArea");
  area.innerHTML = `
    <a href="${data}" download="${filename}"
       style="
         display:inline-block;
         margin-top:10px;
         padding:10px 16px;
         background:#0a66c2;
         color:#fff;
         border-radius:6px;
         text-decoration:none;
         font-weight:600;">
       Download ${filename}
    </a>
    <br>
    <small>Tap ya long-press → Download</small>
  `;
}

/* ================= JPG ================= */
function downloadJPG() {
  let data = canvas.toDataURL("image/jpeg", 0.95);
  showDownloadLink(data, "photo.jpg");
}

/* ================= PNG ================= */
function downloadPNG() {
  let data = canvas.toDataURL("image/png");
  showDownloadLink(data, "photo.png");
}

/* ================= PDF HD ================= */
function downloadPDF() {
  const { jsPDF } = window.jspdf;
  let pdf = new jsPDF("p", "mm", "a4");
  let imgData = canvas.toDataURL("image/jpeg", 1.0);

  let pageWidth = 210;
  let imgWidth = pageWidth - 20;
  let imgHeight = (canvas.height * imgWidth) / canvas.width;

  pdf.addImage(imgData, "JPEG", 10, 10, imgWidth, imgHeight);
  let pdfData = pdf.output("datauristring");

  showDownloadLink(pdfData, "photo.pdf");
}